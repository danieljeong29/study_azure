function fnIsOurCustomBrowser()
	{
		//Check to see if this is our custom
		//browser. We just see if the function 
		//IsOurCustomBrowser is available. By leaving
		//the brackets off of our function it is treated
		//as a property and thus allows us to check if
		//our method exists in the external window. If it
		//returns null then obviously this is not our custom
		//browser, so we return false.
		if(window.external.CB_IsOurCustomBrowser!=null)
			return true;
		else 
			return false;
	}	
	
	//setup a variable to let us know if this is our
	//custom browser.
	/*bIsCustomBrowser = fnIsOurCustomBrowser();

	if(!bIsCustomBrowser)
	{
		//You can check here to see if they have our custom browser.
		//If they don't you can do whatever you want, redirect them
		//to another page or whatever. For the purposes of this example
		//I will just alert them
		//alert('You must be using Custom Browser to view this page properly.');
	}*/

	function fnCallFunction()
	{
		//Call c++ function that we made
		//in our custom browser
		if(bIsCustomBrowser)
		window.external.CB_CustomFunction();
	}	

	function fnCallFunctionWithParams(strString, nNumber)
	{
		//Call c++ function that accepts parameters 
		//that we made in our custom browser
		//if(bIsCustomBrowser)
		window.external.CB_CustomFunctionWithParams(strString, nNumber);
	}

	function fnOpenWindow(strURL, nLeft, nTop, nWidth, nHeight, nResizable)
	{
		//if(bIsCustomBrowser)
		window.external.CB_OpenWindow(strURL, nLeft, nTop, nWidth, nHeight, nResizable);
	}

	function fnShowModalDialog(strURL, nLeft, nTop, nWidth, nHeight)
	{
		//if(bIsCustomBrowser)
		ret = window.external.CB_ShowModalDialog(strURL, nLeft, nTop, nWidth, nHeight);
		document.getElementById("p1").innerHTML=ret;
	}

	function fnShowModelessDialog(strURL, nLeft, nTop, nWidth, nHeight)
	{
		//if(bIsCustomBrowser)
		window.external.CB_ShowModelessDialog(strURL, nLeft, nTop, nWidth, nHeight);
	}
	
	function fnGotoUrl(strURL,strParam)
	{
		//if(bIsCustomBrowser)
		window.external.CB_GotoUrl(strURL, strParam);
	}
	
	function fnCommitDoing()
	{
		if (is_end == 0){
			var ExamID =  parseInt(document.getElementById("CurExamID").innerHTML);
			var istag=0;
			//保存答案
			var  AnswerOrder = "ABCDEFGHIJKT"
			var  ExamAnswer = "";
			for (var i = 0; i < AnswerOrder.length; i++) 
			{
				var TempID = 'answer_' + AnswerOrder.charAt(i);
				if (document.getElementById(TempID) != null)
				{
					ischecked = document.getElementById(TempID).checked;
					if (ischecked == 1)
					{
						ExamAnswer += AnswerOrder.charAt(i);
					}
				}
				
			}
			window.external.CB_RunFunction("CB_SetExamAnswer",ExamID,ExamAnswer);
			//提示答案错误。并显示正确答案。
			//exam_standardanswer
			
			//保存TAG
			istag = document.getElementById("tagexam").checked;
			istag = istag==true?1:0;
			window.external.CB_RunFunction("CB_SetExamTag",ExamID,istag);
			
			//保存备注
			
			return ExamID;
		}
	}
	
	function fnGetExam(type)
	{
	    $.messager.defaults.tips = $.messager.defaults.messageTips;
		//考虑到从试题列表中跳转过来，考虑在考试系统中保存当前题号。
		//var ExamID =  parseInt(document.getElementById("CurExamID").innerHTML);
		var ExamID =  window.external.CB_RunFunction("CB_GetCurrExamID");
		if (ExamID==0) ExamID++;
		var istag=0;
		if (type != 0)
		{
			fnCommitDoing();
			//改变题号
			ExamID = ExamID + type;
			if (ExamID < 1) ExamID=1;
			//判断最大题号
		}
		else
		{
			//新进入页面，直接跳转过来的，不需要保存考试信息。
			var ShowAnswer = window.external.CB_RunFunction("CB_GetExamShowAnswer");
			if (!ShowAnswer)
			{
				document.getElementById("bnShowAnswer").style.display="none"
			}
			var MaxExamID = window.external.CB_RunFunction("CB_GetExamCountByClass",0);
			document.getElementById("MaxExamID").innerText  = MaxExamID.toString();
		}
		
		//获取试题信息
		var ExamHtml = window.external.CB_GetExamByID(ExamID);
		//已经是最后一道题目
		if (!ExamHtml)
		{
		    $.messager.defaults.ok = lang.Actions.Submit;
            $.messager.defaults.cancel = lang.Actions.Continue;
            $.messager.confirm(lang.JSTips.ConfirmTitle, lang.JSTips.LastExam, function (r) {
                if (r) {
					fnSubmitExam();
                    //fnGotoUrl('exam_end.html', '');
                }
				else
				{
				}
            })
			//恢复原来考题序号。
			return ;
		}
		document.getElementById("CurExamID").innerText = ExamID.toString(); //ExamID.toString(); //
		document.getElementById("exam_context").innerHTML  = ExamHtml;
		
		//获取答案并显示
		var  ExamAnswer = window.external.CB_RunFunction("CB_GetExamAnswer",ExamID);
		//alert(ExamAnswer);
		for (var i = 0; i < ExamAnswer.length; i++) 
		{
			var TempID = 'answer_' + ExamAnswer.charAt(i);
			if (document.getElementById(TempID) != null)
			{
				document.getElementById(TempID).checked=1;
			}
		}
		
		//获取TAG
		istag = window.external.CB_RunFunction("CB_GetExamTag",ExamID);
		document.getElementById("tagexam").checked=istag;
		
		//获取标准答案
		var StdAnswer = window.external.CB_RunFunction("CB_GetExamStandarAnswer",ExamID);
		//$("#StdAnswer").html(StdAnswer);
		document.getElementById("StdAnswer").innerText=StdAnswer;
		//获取备注
	}
	
	function fnGetExamList(type)
	{
		//保存题目
		//获取试题信息
		//新进入页面，直接跳转过来的，不需要保存考试信息。
		var ShowAnswer = window.external.CB_RunFunction("CB_GetExamShowAnswer");
		if (!ShowAnswer)
		{
			document.getElementById("bnErrorList").style.display="none"
		}
			
		var ExamListHtml = window.external.CB_RunFunction("CB_GetExamListByClass",parseInt(type),0);
		document.getElementById("ExamListHtml").innerHTML  = ExamListHtml;
	}
	
	
	function fnTagExam()
	{
		var ExamID =  parseInt(document.getElementById("CurExamID").innerHTML);
		
		//window.external.CB_RunFunction("CB_TagExam",ExamID,document.getElementById("tagexam").checked); //ExamID.toString(); //
		//alert(document.getElementById("tagexam").checked);
		//document.getElementById("ExamHtml").innerHTML  = ExamHtml;
	}
	
	function fnSetShowExamAnswer()
	{
		//var ExamID =  parseInt(document.getElementById("ExamShowAnswer").innerHTML);
		window.external.CB_RunFunction("CB_SetExamShowAnswer",document.getElementById("ExamShowAnswer").checked);
	}
	
	function fnSubmitExam() {
        //提交本题答案
		fnCommitDoing();
		var msg;
		//获取未完成题目数目。
		var UndoExamCount = window.external.CB_RunFunction("CB_GetExamCountByClass",4);
		if (UndoExamCount > 0)
		{
		    msg = lang.JSTips.UnfinishedSubmit;
		}
		else
		{
		    msg = lang.JSTips.SubmitConfirm;
		}
		{
			//提示信息
			$.messager.defaults.ok = lang.Actions.Submit;
            $.messager.defaults.cancel = lang.Actions.Continue;
            $.messager.confirm(lang.JSTips.ConfirmTitle, msg, function (r) {
                if (r) {
					var ExamHtml = window.external.CB_GetExamByID(0);
                    fnGotoUrl('exam_end.html', '');
                }
				else
				{
				}
            })
		}
		//提交答案，跳转到答案列表。
		//fnGotoUrl("exam_end.html","");
    }
	
	function fnInitEndpage()
	{
		var examscore = window.external.CB_RunFunction("CB_GetExamScore");
		var tagcount =  window.external.CB_RunFunction("CB_GetExamCountByClass",2); //ExamID.toString(); //
		var errcount =  window.external.CB_RunFunction("CB_GetExamCountByClass",3);
		//处理无效，需要前台工程师帮忙完善下
		//max len is 850(100分) 100*850/100=85
        //var score = (errcount*850)/100;
        //$("#scoreBar").width(score);
		document.getElementById("exam_tag").innerHTML  = tagcount.toString();
		document.getElementById("exam_false").innerHTML  = errcount.toString();
		
		window.external.CB_RunFunction("CB_SetExamShowAnswer",1);
		
		var PassRate = window.external.CB_RunFunction("CB_GetExamOkScore");
		if (examscore<PassRate)
		{
		    document.getElementById("exam_score").innerHTML = examscore.toString()+ "%";		    
		    document.getElementById("span_result").innerHTML = lang.JSTips.ScoreLowTips + PassRate.toString() + "%";
		}
		else
		{
		    document.getElementById("exam_score").innerHTML = examscore.toString() + "%";		    
		    document.getElementById("span_result").innerHTML = lang.JSTips.ScorePassedTips;
		}
		return examscore;
	}
	
	function fnGotoExam(ExamID)
	{
		//alert(ExamID);
		var ExamHtml = window.external.CB_GetExamByID(ExamID);
		if (is_end)
		{
			fnGotoUrl("exam_end_doing.html","");
		}
		else
		{
			fnGotoUrl("exam_doing.html","");
		}
		return ;
	}
	
	function fnGotoExamList(ExamClassID)
	{
		window.external.CB_RunFunction("CB_SetLastListType",parseInt(ExamClassID));
		if (is_end)
		{
			fnGotoUrl("exam_end_list_all.html","");
		}
		else
		{
			fnGotoUrl("exam_list_all.html","");
		}
	}
	
	function fnGotoEndExamList(ExamClassID)
	{
		window.external.CB_RunFunction("CB_SetLastListType",parseInt(ExamClassID));
		fnGotoUrl('exam_end_list_all.html', '');
	}
	
	
	/*导致开始页面，考试时间，通过率，备注编辑内容无法选择删除。可能由下面导致。*/
	(function () {
	    document.oncontextmenu = new Function("event.returnValue=false;");
	    document.onselectstart = new Function("event.returnValue=false;");
	    document.onkeydown = function () {
	        if (event.ctrlKey && window.event.keyCode == 67) {
	            return false;
	        }
	    }
	})();
	
	window.onload = function () {
	    var titleArea = 80, marginVal = 30, paddingVal = 75, btnVal = 80;
	    var clientHeight = document.body.clientHeight - titleArea - marginVal - paddingVal - btnVal;	    
	    $("#content,#ExamListHtml").height(clientHeight);
	    $("#content,#ExamListHtml").css("overflow", "auto");
	    if ($("#content,#ExamListHtml").hasClass("page_content")) {	        
	        if (clientHeight < 455 && window.screen.height != 768)
	            $("#content,#ExamListHtml").height(clientHeight + 80);
	        else if (window.screen.height == 768) {	           
	            $("#content,#ExamListHtml").height(clientHeight + 32);
	        }
	    }
	}
	window.onresize = function () {
	    var titleArea = 80, marginVal = 30, paddingVal = 75, btnVal = 80;
	    var clientHeight = document.body.clientHeight - titleArea - marginVal - paddingVal - btnVal;	    
	    $("#content,#ExamListHtml").height(clientHeight);
	    if ($("#content,#ExamListHtml").hasClass("page_content")) {
	        if (clientHeight < 455 && window.screen.height != 768)
	            $("#content,#ExamListHtml").height(clientHeight + 80);
	        else if (window.screen.height == 768)
	            $("#content,#ExamListHtml").height(clientHeight + 32);
	    }
	}

	function showLang(obj)
	{
	    document.write(obj);
	}