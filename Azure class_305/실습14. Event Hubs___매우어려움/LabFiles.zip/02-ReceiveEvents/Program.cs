﻿using System;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Consumer;
using Azure.Messaging.EventHubs.Processor;

namespace _02_ReceiveEvents
{
  class Program
  {
    private const string connectionString = "<Event_Hub_Connection_String>";
    private const string eventHubName = "<Event_Hub_Name>";
    private const string blobStorageConnectionString = "<Blob_Connection_String>";
    private const string blobContainerName = "<Container_Name>";
    static async Task Main()
    {
      string consumerGroup = EventHubConsumerClient.DefaultConsumerGroupName;

      // Event Processor가 사용할 blob 컨테이너 클라이언트 만들기
      BlobContainerClient storageClient = new BlobContainerClient(blobStorageConnectionString, blobContainerName);

      // Event Hub에서 이벤트를 처리할 Event Processor 클라이언트 만들기
      EventProcessorClient processor = new EventProcessorClient(storageClient, consumerGroup, connectionString, eventHubName);

      // 이벤트 처리와 에러 핸들링을 위한 핸들러 등록
      processor.ProcessEventAsync += ProcessEventHandler;
      processor.ProcessErrorAsync += ProcessErrorHandler;

      // 프로세싱 시작
      await processor.StartProcessingAsync();

      // 처리할 이벤트를 위해 10초 동안 대기
      await Task.Delay(TimeSpan.FromSeconds(10));

      // 프로세싱 중지
      await processor.StopProcessingAsync();
    }
    static async Task ProcessEventHandler(ProcessEventArgs eventArgs)
    {
      // 콘솔창에 이벤트 본문 쓰기
      Console.WriteLine("\tReceived event: {0}", Encoding.UTF8.GetString(eventArgs.Data.Body.ToArray()));

      // blob 스토리지에 체크포인트를 업데이트하여 앱이 다음 실행 시 새로운 이벤트만 수신
      await eventArgs.UpdateCheckpointAsync(eventArgs.CancellationToken);
    }
    static Task ProcessErrorHandler(ProcessErrorEventArgs eventArgs)
    {
      // 에러 세부 내용을 콘솔창에 쓰기
      Console.WriteLine($"\tPartition '{ eventArgs.PartitionId}': an unhandled exception was encountered. This was not expected to happen.");
      Console.WriteLine(eventArgs.Exception.Message);
      return Task.CompletedTask;
    }
  }
}