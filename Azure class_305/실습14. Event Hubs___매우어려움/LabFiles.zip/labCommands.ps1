##### TASK 01 #####
# 프로젝트 초기화
dotnet new console

# 프로젝트에 패키지 추가
dotnet add package Azure.Messaging.EventHubs
dotnet add package Azure.Messaging.EventHubs.Producer

# 패키지 확인
dotnet restore 

# 애플리케이션 빌드
dotnet build

# 애플리케이션 실행
dotnet run


##### TASK 04 #####
# 프로젝트 초기화
dotnet new console

# 프로젝트에 패키지 추가
dotnet add package Azure.Messaging.EventHubs
dotnet add package Azure.Messaging.EventHubs.Consumer
dotnet add package Azure.Messaging.EventHubs.Processor

# 패키지 확인
dotnet restore 

# Azure Blob Storage 용 패키지 추가
dotnet add package Azure.Storage.Blobs

# 빌드 및 실행
dotnet build
dotnet run