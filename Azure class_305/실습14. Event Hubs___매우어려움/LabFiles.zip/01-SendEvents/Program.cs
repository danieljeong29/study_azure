﻿using System;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Producer;

namespace _01_SendEvents
{
  class Program
  {
    private const string connectionString = "<Event_Hub_Connection_String>";
    private const string eventHubName = "<Event_Hub_Name>";
    static async Task Main()
    {
      // Event Hub로 이벤트를 보내는데 사용할 수 있는 Producer Client 만들기
      await using (var producerClient = new EventHubProducerClient(connectionString, eventHubName))
      {
        // 이벤트 배치 만들기
        using EventDataBatch eventBatch = await producerClient.CreateBatchAsync();

        // 배치에 이벤트 추가. 이벤트는 byte와 메타데이터의 컬렉션으로 표현됨
        eventBatch.TryAdd(new EventData(Encoding.UTF8.GetBytes("First event")));
        eventBatch.TryAdd(new EventData(Encoding.UTF8.GetBytes("Second event")));
        eventBatch.TryAdd(new EventData(Encoding.UTF8.GetBytes("Third event")));

        // 이벤트의 배치를 Event Hub로 전송하기 위해 Producer Client 사용
        await producerClient.SendAsync(eventBatch);
        Console.WriteLine("A batch of 3 events has been published.");
      }
    }
  }
}