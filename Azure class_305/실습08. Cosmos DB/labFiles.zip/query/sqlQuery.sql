-- 조건으로 쿼리
SELECT * 
FROM Families f 
WHERE f.id = "WakefieldFamily"

-- JOIN 문
SELECT c.givenName 
FROM Families f 
JOIN c IN f.children 
WHERE f.id = 'WakefieldFamily'

-- 개체
SELECT {"Name":f.id, "City":f.address.city} AS Family
FROM Families f
WHERE f.address.city = f.address.state

-- 배열
SELECT [f.address.city, f.address.state] AS CityState
FROM Families f

-- 집계
SELECT value COUNT(child)
FROM child IN Families.children