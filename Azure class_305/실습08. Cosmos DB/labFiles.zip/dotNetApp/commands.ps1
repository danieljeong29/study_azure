# 새 콘솔 애플리케이션 만들기
cd dotNetApp
dotnet new console

# Cosmos DB 패키지 추가
dotnet add package Microsoft.Azure.Cosmos