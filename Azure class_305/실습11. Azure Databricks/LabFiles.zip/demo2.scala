// Databricks Notebook 소스 지정
val containerName = "<container_name>"
val storageAccountName = "<storage_account_name>"
val sas = "<sas_token>"

val url = "wasbs://" + containerName + "@" + storageAccountName + ".blob.core.windows.net/"
var config = "fs.azure.sas." + containerName + "." + storageAccountName + ".blob.core.windows.net"

// 스토리지 계정 마운트
dbutils.fs.mount(
  source = url,
  mountPoint = "/mnt/staging",
  extraConfigs = Map(config -> sas))

// JSON 파일을 읽고 내용을 출력
val df = spark.read.json("/mnt/staging/small_radio_json.json")
display(df)

// 일부 열 값만 표시
val specificColumnsDf = df.select("firstname", "lastname", "gender", "location", "level")
display(specificColumnsDf)

// 데이터 프레임의 기존 열 이름 변경
val renamedColumnsDF = specificColumnsDf.withColumnRenamed("level", "subscription_type")
display(renamedColumnsDF)

// 새로운 뷰 만들기
renamedColumnsDF.createOrReplaceTempView("renamed")

// SQL 쿼리로 구독별 수 확인
%sql
SELECT 
  count(*) as count,
  subscription_type
FROM renamed
GROUP BY 
  subscription_type

// 새 데이터 프레임 만들기
val aggregate = spark.sql("""
SELECT 
   count(*) as count,
   subscription_type
FROM renamed
GROUP BY 
   subscription_type
""")

// 데이터 프레임을 Blob 스토리지에 저장
aggregate.write.mode("overwrite").csv("/mnt/staging/output/aggregate.csv")