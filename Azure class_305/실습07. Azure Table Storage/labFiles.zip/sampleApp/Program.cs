﻿using System;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos.Table;

namespace demo 
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Table Storage Sample!");

      var storageConnectionString = "[STORAGE_CONNECTION_STRING]";
      var tableName = "tableDemo4";

      CloudStorageAccount storageAccount;
      storageAccount = CloudStorageAccount.Parse(storageConnectionString);

      CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());
      CloudTable table = tableClient.GetTableReference(tableName);

      CustomerEntity customer = new CustomerEntity("Maggie", "Simpson")
      {
        Email = "MarggieSimpson@contoso.com",
        PhoneNumber = "82-2-555-8950"
      };


      MergeUser(table, customer).Wait();
      QueryUser(table, "Maggie", "Simpson").Wait();
    }

    public static async Task MergeUser(CloudTable table, CustomerEntity customer) {
      TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(customer);

      // 작업 실행
      TableResult result = await table.ExecuteAsync(insertOrMergeOperation);
      CustomerEntity? insertedCustomer = result.Result as CustomerEntity;

      Console.WriteLine("New user is added.");
    }

    public static async Task QueryUser(CloudTable table, string firstName, string lastName) {
      TableOperation retrieveOperation = TableOperation.Retrieve<CustomerEntity>(firstName, lastName);
      
      TableResult result = await table.ExecuteAsync(retrieveOperation);
      CustomerEntity? customer = result.Result as CustomerEntity;

      if (customer != null)
      {
        Console.WriteLine("Fetched \t{0}\t{1}\t{2}\t{3}",
          customer.PartitionKey, customer.RowKey, customer.Email, customer.PhoneNumber);
      }
    }
  }

  public class CustomerEntity : TableEntity
  {
    public CustomerEntity() {}
    public CustomerEntity(string lastName, string firstName)
    {
      PartitionKey = lastName;
      RowKey = firstName;
    }
    public string? Email { get; set; }
    public string? PhoneNumber { get; set; }
  }
}
