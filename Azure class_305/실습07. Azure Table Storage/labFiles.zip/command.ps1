# 새 콘솔 애플리케이션 실행
cd .\sampleApp\
dotnet new console

# 패키지 추가
dotnet add package Microsoft.Azure.Cosmos.Table

# 애플리케이션 빌드
dotnet build

# 애플리케이션 실행
dotnet run